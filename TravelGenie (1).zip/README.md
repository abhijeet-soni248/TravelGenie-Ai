
  # TravelGenie

  This is a code bundle for TravelGenie. The original project is available at https://www.figma.com/design/qJbDDchDtqDzTNoY36rTKW/TravelGenie.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  